We are moving to a new home! See https://github.com/microsoft/vscode-go/issues/3247.
Please send your pull request to https://github.com/golang/vscode-go instead.
